import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import threading

class Chat2(Node):
    def __init__(self):
        super().__init__('chat_2')

        self.publisher_ = self.create_publisher(String, 'chat_topic_2', 10)
        self.subscription_ = self.create_subscription(String, 'chat_topic_1', self.receive_message, 10)

        self.send_thread = threading.Thread(target=self.send_messages)
        self.send_thread.start()

    def send_messages(self):
        print("Chat Application 2\n")
        while rclpy.ok():
            try:
                message = input("Enter message: ")
                if not rclpy.ok():
                    break
                msg = String()
                msg.data = message
                self.publisher_.publish(msg)
            except KeyboardInterrupt:
                break

    def receive_message(self, msg):
        print(f"\nReceived message: {msg.data}")
        print("Enter message: ", end='', flush=True)

def main(args=None):
    rclpy.init(args=args)
    chat_node = Chat2()
    executor = rclpy.executors.MultiThreadedExecutor()
    executor.add_node(chat_node)

    spin_thread = threading.Thread(target=executor.spin)
    spin_thread.start()

    try:
        spin_thread.join() 
    except KeyboardInterrupt:
        print("\nShutting down chat")

    chat_node.send_thread.join()

    chat_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
