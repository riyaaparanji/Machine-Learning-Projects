import rclpy
from rclpy.node import Node
from bob_paintings.srv import ProcessImage
import numpy as np

class ImageProcessor(Node):
    def __init__(self):
        super().__init__('image_processor')
        self.srv = self.create_service(ProcessImage, 'process_image', self.process_image_callback)
        
    def sobel_filter(self, image):
        kernel_x = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]])
        kernel_y = np.array([[-1, -2, -1], [0, 0, 0], [1, 2, 1]])
        
        image = np.array(image)
        filtered_x = np.zeros_like(image)
        filtered_y = np.zeros_like(image)
        
        rows, cols = image.shape
        for i in range(1, rows - 1):
            for j in range(1, cols - 1):
                filtered_x[i, j] = np.sum(image[i-1:i+2, j-1:j+2] * kernel_x)
                filtered_y[i, j] = np.sum(image[i-1:i+2, j-1:j+2] * kernel_y)
                
        return np.sqrt(filtered_x**2 + filtered_y**2)
    
    def process_image_callback(self, request, response):
        try:
            processed = self.sobel_filter(request.image)
            response.processed_image = processed.tolist()
            response.success = True
        except Exception as e:
            self.get_logger().error(f'Error processing image: {str(e)}')
            response.success = False
        return response

def main():
    rclpy.init()
    image_processor = ImageProcessor()
    rclpy.spin(image_processor)
    rclpy.shutdown()

if __name__ == '__main__':
    main()