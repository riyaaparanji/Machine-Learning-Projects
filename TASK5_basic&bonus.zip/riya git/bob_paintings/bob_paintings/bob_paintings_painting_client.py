import rclpy
from rclpy.node import Node
from bob_paintings.srv import ProcessImage
import numpy as np

class ImageClient(Node):
    def __init__(self):
        super().__init__('image_client')
        self.client = self.create_client(ProcessImage, 'process_image')
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Service not available, waiting...')
        self.req = ProcessImage.Request()

    def send_request(self):
        test_image = np.array([
            [0, 0, 0, 0, 0],
            [0, 1, 1, 1, 0],
            [0, 1, 2, 1, 0],
            [0, 1, 1, 1, 0],
            [0, 0, 0, 0, 0]
        ], dtype=np.float32)
        
        self.req.image = test_image.tolist()
        self.future = self.client.call_async(self.req)
        return self.future

def main():
    rclpy.init()
    client = ImageClient()
    future = client.send_request()
    
    rclpy.spin_until_future_complete(client, future)
    
    if future.result() is not None:
        response = future.result()
        print(f'Success: {response.success}')
        if response.success:
            print('Processed image:')
            print(np.array(response.processed_image))
    else:
        client.get_logger().error('Service call failed')
    
    client.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()